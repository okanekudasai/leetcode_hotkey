var run_button_click = () => {
    document.querySelector('#run-code').click();
}